package models

type Article struct {
	BlogTitle   string
	BlogArticle string
}
