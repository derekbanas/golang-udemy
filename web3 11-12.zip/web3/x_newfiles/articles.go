package models

// 15. Used to store and get data from our database
type Article struct {
	BlogTitle   string
	BlogArticle string
}
