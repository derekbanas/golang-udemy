package forms

import (
	"fmt"
	"net/http"
	"net/url"
	"strings"

	"github.com/asaskevich/govalidator"
)

type Form struct {
	url.Values
	Errors errors
}

func New(data url.Values) *Form {
	return &Form{
		data,
		errors(map[string][]string{}),
	}
}

// 16. We can pass multiple fields and verify each field
// contains valid data (Now update handlers)
func (f *Form) HasRequired(tagIDs ...string) {
	for _, tagID := range tagIDs {
		value := f.Get(tagID)
		// Trim whitespace
		if strings.TrimSpace(value) == "" {
			f.Errors.AddError(tagID, "This field can't be blank")
		}
	}
}

// 16. Function that verifies that input has a minimum length
// Now Update handlers
func (f *Form) MinLength(tagID string, length int, r *http.Request) bool {
	x := r.Form.Get(tagID)
	if len(x) < length {
		f.Errors.AddError(tagID, fmt.Sprintf("This field must be at least %d characters long", length))
		return false
	}
	return true
}

func (f *Form) HasValue(tagID string, r *http.Request) bool {
	x := r.Form.Get(tagID)
	// if x == "" {
	// 	f.Errors.AddError(tagID, "Field Empty")
	// 	return false
	// }

	// 16. We don't add the error here anymore
	return x != ""
}

func (f *Form) Valid() bool {
	return len(f.Errors) == 0
}

// 16. Get GoValidator can be used to validate different
// types of field data
// go get github.com/asaskevich/govalidator
// (Now add the check to handlers)

func (f *Form) IsEmail(tagID string) {
	if !govalidator.IsEmail(f.Get(tagID)) {
		f.Errors.AddError(tagID, "Invalid Email")
	}
}
